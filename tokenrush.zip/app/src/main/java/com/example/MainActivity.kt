package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.data.*
import com.example.ui.screens.*
import com.example.ui.theme.TokenRushTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var database: AppDatabase
    private lateinit var repository: TokenRushRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize State Room Database locally
        database = AppDatabase.getDatabase(this)
        repository = TokenRushRepository(database.appDao())

        // Initial setup for configurations
        lifecycleScope.launch {
            repository.ensureDefaultSettings()
        }

        enableEdgeToEdge()

        setContent {
            TokenRushTheme {
                // Application-wide session and router state
                var currentUser by remember { mutableStateOf<UserEntity?>(null) }
                var currentRoute by remember { mutableStateOf(Routes.Splash) }
                
                // Sandbox and Security simulators state
                var simulatedEmulator by remember { mutableStateOf(false) }
                var simulatedVpn by remember { mutableStateOf(false) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        AppBottomBar(
                            currentRoute = currentRoute,
                            onNavigate = { currentRoute = it }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentRoute,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            },
                            label = "screen_transitions"
                        ) { targetRoute ->
                            when (targetRoute) {
                                Routes.Splash -> {
                                    SplashScreen(
                                        onSplashFinished = {
                                            currentRoute = Routes.Login
                                        }
                                    )
                                }
                                Routes.Login -> {
                                    LoginScreen(
                                        onLoginSuccess = { user ->
                                            currentUser = user
                                            currentRoute = Routes.Home
                                        },
                                        repository = repository
                                    )
                                }
                                Routes.Home -> {
                                    currentUser?.let { user ->
                                        HomeScreen(
                                            user = user,
                                            repository = repository,
                                            onNavigate = { currentRoute = it },
                                            simulatedEmulator = simulatedEmulator,
                                            simulatedVpn = simulatedVpn
                                        )
                                    }
                                }
                                Routes.Wallet -> {
                                    currentUser?.let { user ->
                                        WalletScreen(
                                            user = user,
                                            repository = repository
                                        )
                                    }
                                }
                                Routes.Rewards -> {
                                    currentUser?.let { user ->
                                        RewardsScreen(
                                            user = user,
                                            repository = repository
                                        )
                                    }
                                }
                                Routes.Referral -> {
                                    currentUser?.let { user ->
                                        ReferralScreen(
                                            user = user,
                                            repository = repository
                                        )
                                    }
                                }
                                Routes.Profile -> {
                                    currentUser?.let { user ->
                                        ProfileScreen(
                                            user = user,
                                            onLogout = {
                                                currentUser = null
                                                currentRoute = Routes.Login
                                            },
                                            onNavigate = { currentRoute = it },
                                            repository = repository,
                                            emulatorFlag = simulatedEmulator,
                                            onToggleEmulator = { simulatedEmulator = it },
                                            vpnFlag = simulatedVpn,
                                            onToggleVpn = { simulatedVpn = it }
                                        )
                                    }
                                }
                                Routes.Admin -> {
                                    AdminDashboardScreen(
                                        repository = repository,
                                        onNavigate = { currentRoute = it }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
