package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // --- USER ---
    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    suspend fun getUserById(uid: String): UserEntity?

    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET isBanned = :isBanned WHERE uid = :uid")
    suspend fun updateUserBanStatus(uid: String, isBanned: Boolean)

    // --- WALLET ---
    @Query("SELECT * FROM wallet WHERE userId = :userId LIMIT 1")
    suspend fun getWalletDirect(userId: String): WalletEntity?

    @Query("SELECT * FROM wallet WHERE userId = :userId LIMIT 1")
    fun getWalletFlow(userId: String): Flow<WalletEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: WalletEntity)

    @Update
    suspend fun updateWallet(wallet: WalletEntity)

    // --- TRANSACTIONS ---
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsForUser(userId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactionsFlow(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    // --- REFERRALS ---
    @Query("SELECT * FROM referrals WHERE userId = :userId ORDER BY dateReferred DESC")
    fun getReferralsForUser(userId: String): Flow<List<ReferralEntity>>

    @Query("SELECT COUNT(*) FROM referrals WHERE userId = :userId")
    suspend fun getReferralsCount(userId: String): Int

    @Query("SELECT COUNT(*) FROM referrals WHERE userId = :userId AND isWeeklyActive = 1")
    suspend fun getActiveReferralsCount(userId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReferral(referral: ReferralEntity)

    // --- WITHDRAWALS ---
    @Query("SELECT * FROM withdrawals WHERE userId = :userId ORDER BY timestamp DESC")
    fun getWithdrawalsForUser(userId: String): Flow<List<WithdrawalEntity>>

    @Query("SELECT * FROM withdrawals ORDER BY timestamp DESC")
    fun getAllWithdrawalsFlow(): Flow<List<WithdrawalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWithdrawal(withdrawal: WithdrawalEntity)

    @Update
    suspend fun updateWithdrawal(withdrawal: WithdrawalEntity)

    // --- DAILY AD LOGS ---
    @Query("SELECT * FROM daily_ad_logs WHERE userId = :userId AND dateStr = :dateStr LIMIT 1")
    suspend fun getDailyAdLog(userId: String, dateStr: String): DailyAdLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyAdLog(log: DailyAdLog)

    // --- FRAUD LOGS ---
    @Query("SELECT * FROM fraud_logs ORDER BY timestamp DESC")
    fun getAllFraudLogsFlow(): Flow<List<FraudLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFraudLog(log: FraudLog)

    // --- SYSTEM CONFIG / SETTINGS ---
    @Query("SELECT * FROM system_settings WHERE id = 1 LIMIT 1")
    suspend fun getSystemSettingsDirect(): SystemSettings?

    @Query("SELECT * FROM system_settings WHERE id = 1 LIMIT 1")
    fun getSystemSettingsFlow(): Flow<SystemSettings?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettings(settings: SystemSettings)

    // --- NOTIFICATIONS ---
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY timestamp DESC")
    fun getNotificationsFlow(userId: String): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllNotificationsAsRead(userId: String)
}
