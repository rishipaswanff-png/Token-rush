package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val uid: String,
    val email: String,
    val displayName: String,
    val phone: String,
    val referralCode: String,
    val referredBy: String?,
    val isBanned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallet")
data class WalletEntity(
    @PrimaryKey val userId: String,
    val totalTokens: Int = 0,
    val availableBalance: Int = 0,
    val lifetimeEarnings: Int = 0,
    val referralEarnings: Int = 0,
    val upiId: String = ""
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val amountTokens: Int,
    val amountInr: Double,
    val type: String, // "REWARD_AD", "REFERRAL_BONUS", "DAILY_BONUS", "STREAK_BONUS", "WEEK_BONUS", "WITHDRAWAL_UPI", "WITHDRAWAL_GIFTCARD"
    val description: String,
    val status: String, // "COMPLETED", "PENDING", "FAILED"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "referrals")
data class ReferralEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,      // Referrer user ID
    val referredUserId: String, // New registered user
    val referredUserEmail: String,
    val dateReferred: Long = System.currentTimeMillis(),
    val isWeeklyActive: Boolean = true, // Whether they did at least 5 ads this week
    val rewardCredited: Boolean = true
)

@Entity(tableName = "withdrawals")
data class WithdrawalEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val type: String, // "UPI", "AMAZON", "FLIPKART", "GOOGLE_PLAY"
    val amountTokens: Int,
    val amountInr: Double,
    val destination: String, // UPI ID or Email address
    val giftCardCode: String = "", // Populated like "AMZN-XXXX-Y" upon approval
    val status: String, // "PENDING", "APPROVED", "REJECTED"
    val timestamp: Long = System.currentTimeMillis(),
    val remarks: String = ""
)

@Entity(tableName = "daily_ad_logs")
data class DailyAdLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val dateStr: String, // Format "yyyy-MM-dd"
    val count: Int
)

@Entity(tableName = "fraud_logs")
data class FraudLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val threatType: String, // "EMULATOR", "VPN", "ROOT_DETECTED", "RATE_LIMIT", "DUPLICATE_DEVICE", "BOT_SPEED"
    val description: String,
    val deviceFingerprint: String,
    val ipAddress: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "system_settings")
data class SystemSettings(
    @PrimaryKey val id: Int = 1,
    val rewardPerAd: Int = 10,
    val dailyLimit: Int = 10,
    val conversionRate: Double = 1.0, // Tokens to INR conversion (e.g. 100 tokens = 1 USD/INR. Let's make 10 tokens = 1 INR, or 100 tokens = 90 INR / configurable) Setup: 100 tokens = ₹10 (meaning 10 tokens = 1 INR) or Custom
    val tokensPerInrRate: Double = 10.0, // 10 tokens = 1 INR
    val referralBonus: Int = 100,
    val minWithdrawalInr: Int = 5
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val title: String,
    val message: String,
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
