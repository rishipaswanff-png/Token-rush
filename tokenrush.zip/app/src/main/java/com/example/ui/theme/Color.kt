package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF00FF99)       // Cash/Mint accent
val SecondaryCyan = Color(0xFF00D2FF)      // Fintech info
val TokenGold = Color(0xFFFFAA00)          // Rewards / tokens
val DarkBg = Color(0xFF0A0B10)              // Deep high-contrast dark space
val SurfaceCard = Color(0xFF151722)         // Container surface
val SurfaceCardVariant = Color(0xFF202336)  // Inner cards / tabs
val TextPrimary = Color(0xFFF0F2FA)         // High emphasis text
val TextSecondary = Color(0xFF909BBC)       // Secondary labels
val GlowRed = Color(0xFFFF3366)             // Alerts/Failed/Banned
val GlowGreen = Color(0xFF00FF66)           // Success
val DividerDark = Color(0xFF2A2D44)         // Card dividers
