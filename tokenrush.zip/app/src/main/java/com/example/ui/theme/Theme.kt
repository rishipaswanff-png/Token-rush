package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryGreen,
    secondary = SecondaryCyan,
    tertiary = TokenGold,
    background = DarkBg,
    surface = SurfaceCard,
    surfaceVariant = SurfaceCardVariant,
    onPrimary = Color(0xFF002211),
    onSecondary = Color(0xFF001F33),
    onTertiary = Color(0xFF331F00),
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    error = GlowRed
)

@Composable
fun TokenRushTheme(
    content: @Composable () -> Unit
) {
    // We enforce the beautiful designed dark theme since the specs strictly demand it
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
