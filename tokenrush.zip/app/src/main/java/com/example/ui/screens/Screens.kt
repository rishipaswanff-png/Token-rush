package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// --- MAIN NAV HOST ROUTING KEYS ---
object Routes {
    const val Splash = "splash"
    const val Login = "login"
    const val Home = "home"
    const val Wallet = "wallet"
    const val Referral = "referral"
    const val Rewards = "rewards"
    const val Profile = "profile"
    const val Admin = "admin"
}

// --- SHARED NAVIGATION LAYOUT ---
@Composable
fun AppBottomBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    if (currentRoute == Routes.Splash || currentRoute == Routes.Login) return

    NavigationBar(
        containerColor = SurfaceCard,
        contentColor = TextSecondary,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            selected = currentRoute == Routes.Home,
            onClick = { onNavigate(Routes.Home) },
            icon = { Icon(Icons.Filled.Home, "Home", tint = if (currentRoute == Routes.Home) PrimaryGreen else TextSecondary) },
            label = { Text("Home", color = if (currentRoute == Routes.Home) TextPrimary else TextSecondary) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = SurfaceCardVariant)
        )
        NavigationBarItem(
            selected = currentRoute == Routes.Wallet,
            onClick = { onNavigate(Routes.Wallet) },
            icon = { Icon(Icons.Filled.Wallet, "Wallet", tint = if (currentRoute == Routes.Wallet) PrimaryGreen else TextSecondary) },
            label = { Text("Wallet", color = if (currentRoute == Routes.Wallet) TextPrimary else TextSecondary) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = SurfaceCardVariant)
        )
        NavigationBarItem(
            selected = currentRoute == Routes.Rewards,
            onClick = { onNavigate(Routes.Rewards) },
            icon = { Icon(Icons.Filled.CardGiftcard, "Rewards", tint = if (currentRoute == Routes.Rewards) PrimaryGreen else TextSecondary) },
            label = { Text("Rewards", color = if (currentRoute == Routes.Rewards) TextPrimary else TextSecondary) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = SurfaceCardVariant)
        )
        NavigationBarItem(
            selected = currentRoute == Routes.Referral,
            onClick = { onNavigate(Routes.Referral) },
            icon = { Icon(Icons.Filled.People, "Invite", tint = if (currentRoute == Routes.Referral) PrimaryGreen else TextSecondary) },
            label = { Text("Invite", color = if (currentRoute == Routes.Referral) TextPrimary else TextSecondary) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = SurfaceCardVariant)
        )
        NavigationBarItem(
            selected = currentRoute == Routes.Profile || currentRoute == Routes.Admin,
            onClick = { onNavigate(Routes.Profile) },
            icon = { Icon(Icons.Filled.Person, "Profile", tint = if (currentRoute == Routes.Profile || currentRoute == Routes.Admin) PrimaryGreen else TextSecondary) },
            label = { Text("Profile", color = if (currentRoute == Routes.Profile || currentRoute == Routes.Admin) TextPrimary else TextSecondary) },
            colors = NavigationBarItemDefaults.colors(indicatorColor = SurfaceCardVariant)
        )
    }
}

// --- 1. SPLASH SCREEN ---
@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }
    val scaleVal = animateFloatAsState(
        targetValue = if (startAnimation) 1.2f else 0.8f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow),
        label = "logo_scale"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2200)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        contentAlignment = Alignment.Center
    ) {
        // Aesthetic space ambient lines
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = PrimaryGreen.copy(alpha = 0.06f),
                radius = 450f,
                center = Offset(size.width, 0f)
            )
            drawCircle(
                color = SecondaryCyan.copy(alpha = 0.05f),
                radius = 350f,
                center = Offset(0f, size.height)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .scale(scaleVal.value)
                    .drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(PrimaryGreen.copy(alpha = 0.2f), Color.Transparent),
                                center = Offset(size.width / 2, size.height / 2),
                                radius = size.width * 0.9f
                            )
                        )
                    }
                    .clip(CircleShape)
                    .background(SurfaceCardVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.OfflineBolt,
                    contentDescription = "TokenRush Logo",
                    tint = PrimaryGreen,
                    modifier = Modifier.size(60.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "TOKEN RUSH",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.SansSerif,
                color = TextPrimary,
                letterSpacing = 4.sp,
                modifier = Modifier.animateContentSize()
            )

            Text(
                text = "Watch. Earn. Redeem.",
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                color = PrimaryGreen,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Subtext at bottom
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
        ) {
            CircularProgressIndicator(
                color = PrimaryGreen,
                strokeWidth = 3.dp,
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

// --- 2. LOGIN SCREEN ---
@Composable
fun LoginScreen(
    onLoginSuccess: (UserEntity) -> Unit,
    repository: TokenRushRepository
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var inviteCodeInput by remember { mutableStateOf("") }

    var isOtpSent by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("EMAIL") } // "EMAIL" or "OTP"
    var isSigningUp by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(PrimaryGreen.copy(alpha = 0.04f), radius = 300f, center = Offset(size.width * 0.2f, 0f))
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.OfflineBolt,
                contentDescription = null,
                tint = PrimaryGreen,
                modifier = Modifier.size(54.dp)
            )

            Text(
                text = "Welcome to TokenRush",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.padding(top = 12.dp)
            )

            Text(
                text = "Log in to earn premium rewarded cashouts",
                fontSize = 13.sp,
                color = TextSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Dynamic Form Status Alert
            if (statusMessage.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isError) GlowRed.copy(alpha = 0.15f) else PrimaryGreen.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isError) Icons.Filled.Error else Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = if (isError) GlowRed else GlowGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = statusMessage,
                            color = if (isError) GlowRed else GlowGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Tab selectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SurfaceCardVariant)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTab = "EMAIL" }
                        .background(if (activeTab == "EMAIL") SurfaceCard else Color.Transparent)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Email Login",
                        fontWeight = FontWeight.SemiBold,
                        color = if (activeTab == "EMAIL") PrimaryGreen else TextSecondary,
                        fontSize = 14.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeTab = "OTP" }
                        .background(if (activeTab == "OTP") SurfaceCard else Color.Transparent)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Mobile OTP",
                        fontWeight = FontWeight.SemiBold,
                        color = if (activeTab == "OTP") PrimaryGreen else TextSecondary,
                        fontSize = 14.sp
                    )
                }
            }

            // EMAIL TAB CONTENT
            if (activeTab == "EMAIL") {
                if (isSigningUp) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Filled.Person, null, tint = TextSecondary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, unfocusedBorderColor = DividerDark)
                    )
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Filled.Email, null, tint = TextSecondary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("email_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, unfocusedBorderColor = DividerDark)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Filled.Lock, null, tint = TextSecondary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, unfocusedBorderColor = DividerDark)
                )

                if (isSigningUp) {
                    OutlinedTextField(
                        value = inviteCodeInput,
                        onValueChange = { inviteCodeInput = it },
                        label = { Text("Referral Invite Code (Optional)") },
                        leadingIcon = { Icon(Icons.Filled.CardGiftcard, null, tint = TextSecondary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        singleLine = true,
                        placeholder = { Text("Earn 100 extra tokens instantly") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = TokenGold, unfocusedBorderColor = DividerDark)
                    )
                }
            } else {
                // OTP TAB CONTENT
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Indian Phone Number (+91)") },
                    leadingIcon = { Icon(Icons.Filled.Phone, null, tint = TextSecondary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    singleLine = true,
                    placeholder = { Text("Enter 10-digit mobile") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, unfocusedBorderColor = DividerDark)
                )

                if (isOtpSent) {
                    OutlinedTextField(
                        value = otpCode,
                        onValueChange = { otpCode = it },
                        label = { Text("6-Digit OTP Code") },
                        leadingIcon = { Icon(Icons.Filled.Key, null, tint = TextSecondary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        singleLine = true,
                        placeholder = { Text("Try code '123456'") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = TokenGold, unfocusedBorderColor = DividerDark)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Primary Button
            Button(
                onClick = {
                    coroutineScope.launch {
                        isError = false
                        statusMessage = "Processing Authentication..."

                        if (activeTab == "EMAIL") {
                            if (email.isBlank() || password.isBlank()) {
                                isError = true
                                statusMessage = "Email and Password cannot be blank."
                                return@launch
                            }
                            // Simulate login registration
                            val user = repository.loginOrRegisterUser(
                                email = email,
                                displayName = if (isSigningUp) fullName.ifBlank { "User" } else email.substringBefore("@"),
                                phone = "+91 98765 43210",
                                referredByCode = if (isSigningUp) inviteCodeInput else null
                            )
                            statusMessage = "Successfully Verified!"
                            delay(500)
                            onLoginSuccess(user)
                        } else {
                            // OTP Flow
                            if (phone.length < 10) {
                                isError = true
                                statusMessage = "Please enter a valid 10-digit mobile."
                                return@launch
                            }

                            if (!isOtpSent) {
                                isOtpSent = true
                                isError = false
                                statusMessage = "OTP sent successfully! Enter '123456' to confirm."
                            } else {
                                if (otpCode != "123456") {
                                    isError = true
                                    statusMessage = "Incorrect OTP code. Please enter '123456' to pass."
                                } else {
                                    val user = repository.loginOrRegisterUser(
                                        email = "${phone}@tokenrush.in",
                                        displayName = "User_${phone.takeLast(4)}",
                                        phone = "+91 $phone",
                                        referredByCode = null
                                    )
                                    statusMessage = "Mobile Verified successfully!"
                                    delay(500)
                                    onLoginSuccess(user)
                                }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_login_button"),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen, contentColor = Color(0xFF002211)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (activeTab == "EMAIL") {
                        if (isSigningUp) "Create Account" else "Sign In securely"
                    } else {
                        if (isOtpSent) "Verify & Log In" else "Send Login OTP"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Auth Google Quick Login mock
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DividerDark, RoundedCornerShape(12.dp))
                    .clickable {
                        coroutineScope.launch {
                            statusMessage = "Connecting security vault..."
                            delay(650)
                            val user = repository.loginOrRegisterUser(
                                email = "g.verify.test@gmail.com",
                                displayName = "Google Verified Account",
                                phone = "+91 8877665544",
                                referredByCode = null
                            )
                            onLoginSuccess(user)
                        }
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.OfflineBolt,
                    contentDescription = null,
                    tint = TokenGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log in with Google Account", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Reset Toggle Signup
            if (activeTab == "EMAIL") {
                Text(
                    text = if (isSigningUp) "Already have an account? Sign In" else "New to TokenRush? Create free account",
                    color = PrimaryGreen,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clickable { isSigningUp = !isSigningUp }
                        .padding(8.dp)
                )
            }
        }
    }
}

// --- 3. HOME SCREEN ---
@Composable
fun HomeScreen(
    user: UserEntity,
    repository: TokenRushRepository,
    onNavigate: (String) -> Unit,
    simulatedEmulator: Boolean,
    simulatedVpn: Boolean
) {
    val coroutineScope = rememberCoroutineScope()

    // Live Flow variables from repo
    val wallet by repository.getWalletFlow(user.uid).collectAsState(initial = WalletEntity(user.uid))
    val settings by repository.getSystemSettingsFlow().collectAsState(initial = SystemSettings())
    val transactions by repository.getTransactionsForUser(user.uid).collectAsState(initial = emptyList())

    var todaysAdsDone by remember { mutableStateOf(0) }
    LaunchedEffect(key1 = wallet) {
        todaysAdsDone = repository.getDailyAdCount(userId = user.uid)
    }

    // Interactive Ad Modal simulation
    var isPlayingAd by remember { mutableStateOf(false) }
    var adCountProgress by remember { mutableStateOf(0f) }
    var adCapString by remember { mutableStateOf("") }
    var earnLogMessage by remember { mutableStateOf("") }
    var claimLoading by remember { mutableStateOf(false) }

    // Seed/Check dynamic configurations
    val rewardAmount = settings?.rewardPerAd ?: 10
    val limitDaily = settings?.dailyLimit ?: 10
    val inrRate = settings?.tokensPerInrRate ?: 10.0

    val currentRemaining = (limitDaily - todaysAdsDone).coerceAtLeast(0)
    val todayInrEarned = transactions
        .filter { it.type == "REWARD_AD" && isToday(it.timestamp) }
        .sumOf { it.amountTokens } / inrRate

    // Ad Simulation Task Loop
    if (isPlayingAd) {
        val captions = listOf(
            "Fintech Pro: Invest with 0.5% Commission instantly!",
            "E-Commerce Mania: 80% off on premium audio headphones today!",
            "Credit Score Check: Get free analysis report securely.",
            "Fantasy Cricket leagues: Dream and win daily bonuses."
        )
        DisposableEffect(Unit) {
            adCapString = captions.random()
            onDispose {}
        }

        LaunchedEffect(key1 = true) {
            adCountProgress = 0f
            // Progress over 5 short ticks to simulate watching a 5-second reward video
            for (i in 1..5) {
                delay(1000)
                adCountProgress = i / 5.0f
            }
            isPlayingAd = false
            // Call Earn function securely
            val state = repository.watchAdAndEarn(user.uid, simulatedEmulator, simulatedVpn)
            if (state == "SUCCESS") {
                earnLogMessage = "Congratulation! +$rewardAmount tokens credited instantly."
                todaysAdsDone = repository.getDailyAdCount(user.uid)
            } else if (state == "FRAUD_BLOCKED") {
                earnLogMessage = "Security Denied: Anti-Fraud framework active. VPN or Emulator detected."
            } else {
                earnLogMessage = "Daily limit reached. Refresh tomorrow!"
            }
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(PrimaryGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(user.displayName.take(1).uppercase(), color = PrimaryGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Namaste, ${user.displayName}", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Standard Rank Member", color = TextSecondary, fontSize = 11.sp)
                        }
                    }

                    // Top Bar Badges showing safety status
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onNavigate(Routes.Profile) }) {
                            Box(contentAlignment = Alignment.TopEnd) {
                                Icon(Icons.Outlined.Notifications, "Notifications", tint = TextPrimary)
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(TokenGold)
                                )
                            }
                        }
                    }
                }
            }
        },
        containerColor = DarkBg,
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header spacer
                item { Spacer(modifier = Modifier.height(10.dp)) }

                // AD EARNING NOTIFICATION ALERTS
                if (earnLogMessage.isNotEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (earnLogMessage.contains("Denied")) GlowRed.copy(alpha = 0.15f) else SurfaceCardVariant
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.animateContentSize()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (earnLogMessage.contains("Denied")) Icons.Filled.Security else Icons.Filled.Wallet,
                                        contentDescription = null,
                                        tint = if (earnLogMessage.contains("Denied")) GlowRed else PrimaryGreen
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(earnLogMessage, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                                Box(
                                    modifier = Modifier
                                        .clickable { earnLogMessage = "" }
                                        .padding(4.dp)
                                ) {
                                    Icon(Icons.Filled.Close, "Dismiss", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                // WALLET DISPLAY CARD - MODERN FINTECH VIBE
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = PrimaryGreen.copy(0.4f)),
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .drawBehind {
                                    // Subtle diagonal design gradient lines
                                    val brush = Brush.linearGradient(
                                        colors = listOf(PrimaryGreen.copy(0.04f), Color.Transparent)
                                    )
                                    drawRect(brush = brush)
                                }
                                .padding(20.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.OfflineBolt,
                                        contentDescription = null,
                                        tint = TokenGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("CURRENT BALANCE", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SurfaceCardVariant),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "100 Tokens = ₹${String.format("%.2f", 100 / inrRate)}",
                                        fontSize = 10.sp,
                                        color = PrimaryGreen,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.OfflineBolt,
                                    contentDescription = null,
                                    tint = TokenGold,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .align(Alignment.CenterVertically)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${wallet?.availableBalance ?: 0}",
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Tokens",
                                    fontSize = 15.sp,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // INR Equivalent Value
                            val currentInr = (wallet?.availableBalance ?: 0) / inrRate
                            Text(
                                text = "≈ ₹${String.format("%.2f", currentInr)} INR Cash",
                                fontSize = 15.sp,
                                color = PrimaryGreen,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            HorizontalDivider(color = DividerDark)

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Today's Earnings", fontSize = 11.sp, color = TextSecondary)
                                    Text("₹${String.format("%.2f", todayInrEarned)}", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Daily Limits Used", fontSize = 11.sp, color = TextSecondary)
                                    Text("$todaysAdsDone / $limitDaily ads watched", fontSize = 14.sp, color = TokenGold, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // DAILY BONUS & STREAK CLAIM PANEL
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCardVariant),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(PrimaryGreen.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Outlined.CheckCircle, "Daily Check", tint = PrimaryGreen)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Daily Login Bonus", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                                    Text("Claim free 20 Tokens every day!", color = TextSecondary, fontSize = 11.sp)
                                }
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        claimLoading = true
                                        val status = repository.claimDailyLoginBonus(user.uid)
                                        delay(500)
                                        claimLoading = false
                                        earnLogMessage = if (status) "Daily 20 Tokens added successfully!" else "Already claimed today."
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen, contentColor = Color(0xFF002211)),
                                modifier = Modifier.height(36.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Claim", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // WATCH AD REWARD ACCELERATOR ACTIONS
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "TokenRush Rewarded Engines",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                "Watch premium video advertisements to load instant cash balance. High fill-rate server active.",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier
                                    .padding(vertical = 6.dp)
                                    .fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Interactive Watch Advertisement Button
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (currentRemaining > 0) PrimaryGreen else DividerDark
                                    )
                                    .clickable(enabled = currentRemaining > 0 && !isPlayingAd) {
                                        isPlayingAd = true
                                    }
                                    .padding(vertical = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = null,
                                        tint = if (currentRemaining > 0) Color(0xFF002211) else TextSecondary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isPlayingAd) "Loading Rewarded Ad..." else "Watch Ad & Earn +$rewardAmount Tokens",
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (currentRemaining > 0) Color(0xFF002211) else TextSecondary,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Filled.Security, null, tint = SecondaryCyan, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Anti-Fraud server verifying device fingerprint", color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }

                // INLINE TRANSACTION HISTORY PREVIEW
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Recent Actions", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            "View All",
                            color = PrimaryGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { onNavigate(Routes.Wallet) }
                        )
                    }
                }

                if (transactions.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.History, "No activity", tint = TextSecondary, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No actions logged yet. Watch ads to start earning!", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                } else {
                    items(transactions.take(4)) { tx ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    tx.type.contains("WITHDRAWAL") -> GlowRed.copy(alpha = 0.1f)
                                                    else -> PrimaryGreen.copy(alpha = 0.1f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when {
                                                tx.type.contains("WITHDRAWAL") -> Icons.Filled.ArrowUpward
                                                tx.type.contains("REFERRAL") -> Icons.Filled.PersonAdd
                                                else -> Icons.Filled.PlayCircle
                                            },
                                            contentDescription = null,
                                            tint = if (tx.type.contains("WITHDRAWAL")) GlowRed else PrimaryGreen,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = tx.description,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(tx.timestamp)),
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (tx.amountTokens > 0) "+${tx.amountTokens}" else "${tx.amountTokens}",
                                        color = if (tx.amountTokens > 0) GlowGreen else GlowRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = tx.status,
                                        fontSize = 10.sp,
                                        color = if (tx.status == "COMPLETED") PrimaryGreen else TokenGold,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(24.dp)) }
            }

            // SIMULATOR RUNNING AD DIALOG OVERLAY
            if (isPlayingAd) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.85f))
                        .clickable(enabled = false) {}, // Prevent back clicks
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .shadow(24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("TokenRush Simulated Ad Network", fontSize = 11.sp, color = PrimaryGreen, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .drawBehind {
                                        // Draw progress ring around circle
                                        drawCircle(color = DividerDark, style = Stroke(width = 6f))
                                        drawArc(
                                            color = TokenGold,
                                            startAngle = -90f,
                                            sweepAngle = adCountProgress * 360f,
                                            useCenter = false,
                                            style = Stroke(width = 12f)
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${(5 - (adCountProgress * 5).toInt()).coerceAtLeast(0)}s", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = adCapString,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = "Keep ad loaded to credit tokens automatically. Do not exit app.",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )

                            LinearProgressIndicator(
                                progress = { adCountProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = PrimaryGreen,
                                trackColor = DividerDark
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- 4. WALLET SCREEN ---
@Composable
fun WalletScreen(
    user: UserEntity,
    repository: TokenRushRepository
) {
    val wallet by repository.getWalletFlow(user.uid).collectAsState(initial = WalletEntity(user.uid))
    val transactions by repository.getTransactionsForUser(user.uid).collectAsState(initial = emptyList())
    val settings by repository.getSystemSettingsFlow().collectAsState(initial = SystemSettings())

    val inrRate = settings?.tokensPerInrRate ?: 10.0

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text("Wallet Ledger", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Instant secure payment history", fontSize = 12.sp, color = TextSecondary)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // STATS ROW WITH LIFETIME EARNINGS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.AccountBalanceWallet, null, tint = PrimaryGreen)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Available Bal", fontSize = 11.sp, color = TextSecondary)
                        Text("₹${String.format("%.2f", (wallet?.availableBalance ?: 0) / inrRate)}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("${wallet?.availableBalance ?: 0} Tokens", fontSize = 10.sp, color = TokenGold)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.ShowChart, null, tint = SecondaryCyan)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Lifetime Earnings", fontSize = 11.sp, color = TextSecondary)
                        Text("₹${String.format("%.2f", (wallet?.lifetimeEarnings ?: 0) / inrRate)}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("${wallet?.lifetimeEarnings ?: 0} Tokens", fontSize = 10.sp, color = TokenGold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // SECOND STATS ROW WITH REFERRAL INCOME
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Group, null, tint = TokenGold)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Referral Earned", fontSize = 11.sp, color = TextSecondary)
                            Text("₹${String.format("%.2f", (wallet?.referralEarnings ?: 0) / inrRate)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Full Transaction Log", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)

            Spacer(modifier = Modifier.height(10.dp))

            if (transactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.History, null, tint = TextSecondary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("No transactions logged yet", color = TextSecondary, fontSize = 13.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(transactions) { tx ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (tx.amountTokens >= 0) PrimaryGreen.copy(0.1f) else GlowRed.copy(0.1f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (tx.amountTokens >= 0) Icons.Filled.AddCard else Icons.Filled.PriceCheck,
                                            contentDescription = null,
                                            tint = if (tx.amountTokens >= 0) PrimaryGreen else GlowRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(tx.description, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            text = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(tx.timestamp)),
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (tx.amountTokens >= 0) "+${tx.amountTokens}" else "${tx.amountTokens}",
                                        color = if (tx.amountTokens >= 0) GlowGreen else GlowRed,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = tx.status,
                                        fontSize = 10.sp,
                                        color = if (tx.status == "COMPLETED") PrimaryGreen else TokenGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 5. REWARDS SCREEN ---
@Composable
fun RewardsScreen(
    user: UserEntity,
    repository: TokenRushRepository
) {
    val coroutineScope = rememberCoroutineScope()
    val wallet by repository.getWalletFlow(user.uid).collectAsState(initial = WalletEntity(user.uid))
    val settings by repository.getSystemSettingsFlow().collectAsState(initial = SystemSettings())
    val withdrawals by repository.getWithdrawalsForUser(user.uid).collectAsState(initial = emptyList())

    val inrRate = settings?.tokensPerInrRate ?: 10.0
    val minWithdrawal = settings?.minWithdrawalInr ?: 5

    var activeRedemptionType by remember { mutableStateOf("UPI") } // "UPI", "AMAZON", "FLIPKART", "GOOGLE_PLAY"
    var upiIdInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf(user.email) }
    var tokenAmountInput by remember { mutableStateOf("") }

    var logStatusMessage by remember { mutableStateOf("") }
    var isErrorState by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text("Redeem Vouchers", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Supported rewards for Indian active users", fontSize = 12.sp, color = TextSecondary)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // USER CURRENT BALANCE STRIP
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Redeemable Token Balance", fontSize = 11.sp, color = TextSecondary)
                        Text("${wallet?.availableBalance ?: 0} Tokens", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TokenGold)
                    }
                    Text(
                        "≈ ₹${String.format("%.2f", (wallet?.availableBalance ?: 0) / inrRate)}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // CARD SELECTOR FOR REDEMPTION TYPES
            Text("Select Payout Channel", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val channels = listOf("UPI", "AMAZON", "FLIPKART", "GOOGLE_PLAY")
                channels.forEach { name ->
                    val isSelected = activeRedemptionType == name
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) PrimaryGreen else SurfaceCard)
                            .border(1.dp, if (isSelected) Color.Transparent else DividerDark, RoundedCornerShape(10.dp))
                            .clickable {
                                activeRedemptionType = name
                                tokenAmountInput = ""
                            }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = when (name) {
                                    "UPI" -> Icons.Filled.AccountBalance
                                    "AMAZON" -> Icons.Filled.ShoppingBag
                                    "FLIPKART" -> Icons.Filled.LocalMall
                                    else -> Icons.Filled.PlayCircle
                                },
                                contentDescription = null,
                                tint = if (isSelected) Color(0xFF002211) else TextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = when (name) {
                                    "GOOGLE_PLAY" -> "G-Play"
                                    "AMAZON" -> "Amazon"
                                    "FLIPKART" -> "Flipkart"
                                    else -> "UPI"
                                },
                                fontSize = 11.sp,
                                color = if (isSelected) Color(0xFF002211) else TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // REDEMPTION REQUEST INPUT FORM
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Transfer to $activeRedemptionType",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (logStatusMessage.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isErrorState) GlowRed.copy(0.15f) else PrimaryGreen.copy(0.15f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = logStatusMessage,
                                color = if (isErrorState) GlowRed else GlowGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    if (activeRedemptionType == "UPI") {
                        OutlinedTextField(
                            value = upiIdInput,
                            onValueChange = { upiIdInput = it },
                            label = { Text("UPI ID") },
                            placeholder = { Text("username@upi") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                        )
                    } else {
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Receipt Email Address") },
                            placeholder = { Text("Your verified email") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tokenAmountInput,
                        onValueChange = { tokenAmountInput = it },
                        label = { Text("Tokens to Redeem") },
                        placeholder = { Text("Min Value (e.g. ${minWithdrawal * 10} Tokens)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = TokenGold)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    val calcInr = (tokenAmountInput.toIntOrNull() ?: 0) / inrRate
                    Text(
                        text = "You will receive INR: ₹${String.format("%.2f", calcInr)}",
                        fontSize = 13.sp,
                        color = PrimaryGreen,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isErrorState = false
                                val tokenVal = tokenAmountInput.toIntOrNull() ?: 0
                                if (tokenVal <= 0) {
                                    isErrorState = true
                                    logStatusMessage = "Please enter a valid positive token amount."
                                    return@launch
                                }

                                val destination = if (activeRedemptionType == "UPI") upiIdInput else emailInput
                                if (destination.isBlank()) {
                                    isErrorState = true
                                    logStatusMessage = "Field destination address cannot be empty."
                                    return@launch
                                }

                                val stat = repository.requestWithdrawal(
                                    userId = user.uid,
                                    type = activeRedemptionType,
                                    amountTokens = tokenVal,
                                    destination = destination
                                )

                                if (stat == "SUCCESS") {
                                    logStatusMessage = "Success! Requested successfully. Token debited."
                                    upiIdInput = ""
                                    tokenAmountInput = ""
                                } else if (stat == "MIN_LIMIT_FAILED") {
                                    isErrorState = true
                                    logStatusMessage = "Minimum payout ₹$minWithdrawal required (equals ${minWithdrawal * inrRate.toInt()} tokens)."
                                } else if (stat == "INSUFFICIENT_BALANCE") {
                                    isErrorState = true
                                    logStatusMessage = "Insufficient balance in wallet."
                                } else {
                                    isErrorState = true
                                    logStatusMessage = "Redeem error occurred: $stat"
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen, contentColor = Color(0xFF002211)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Confirm Redemption Securely", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // WITHDRAWALS HISTORY LOG LIST
            Text("Previous Redemptions", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            if (withdrawals.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "No dynamic withdrawals logged yet. Your earnings will show up here.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                withdrawals.forEach { wd ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when (wd.type) {
                                            "UPI" -> Icons.Filled.AccountBalance
                                            else -> Icons.Filled.ShoppingBag
                                        },
                                        contentDescription = null,
                                        tint = TokenGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("${wd.type} payout", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = when (wd.status) {
                                            "APPROVED" -> GlowGreen.copy(0.15f)
                                            "REJECTED" -> GlowRed.copy(0.15f)
                                            else -> TokenGold.copy(0.15f)
                                        }
                                    ),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = wd.status,
                                        color = when (wd.status) {
                                            "APPROVED" -> GlowGreen
                                            "REJECTED" -> GlowRed
                                            else -> TokenGold
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("Payout address: ${wd.destination}", color = TextSecondary, fontSize = 12.sp)
                            Text("Units Sent: ${wd.amountTokens} tokens (₹${String.format("%.2f", wd.amountInr)})", color = TextPrimary, fontSize = 13.sp)

                            if (wd.giftCardCode.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "Redemption Code: ${wd.giftCardCode}",
                                    color = PrimaryGreen,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .background(SurfaceCardVariant, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            if (wd.remarks.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("System Remarks: ${wd.remarks}", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// --- 6. REFERRAL SCREEN ---
@Composable
fun ReferralScreen(
    user: UserEntity,
    repository: TokenRushRepository
) {
    val settings by repository.getSystemSettingsFlow().collectAsState(initial = SystemSettings())
    val referrals by repository.getReferralsForUser(user.uid).collectAsState(initial = emptyList())

    val bonusAmount = settings?.referralBonus ?: 100

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Text("Invite & Earn", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Receive reward tokens and weekly bonuses together", fontSize = 12.sp, color = TextSecondary)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // REFERRAL BANNER GRAPHICS
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.Stars,
                        contentDescription = null,
                        tint = TokenGold,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Share the rush, double the rewards!",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        "You get +$bonusAmount tokens, and your friend gets +$bonusAmount tokens instantly upon unique verified email or OTP registration.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // THE SHARE CODE CONTAINER
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCardVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Your Unique Invitation Code", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(SurfaceCard, RoundedCornerShape(8.dp))
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = user.referralCode,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreen,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "Copy code",
                            tint = TokenGold,
                            modifier = Modifier
                                .clickable {
                                    // Simulated clipboard
                                }
                                .size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            // Link simulation sharing
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen, contentColor = Color(0xFF002211)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Share, "Invite Friend", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share Invite Link", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // LEADERBOARDS OR REFS REGISTERED LOGGER
            Text("Invited Connections (${referrals.size})", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            if (referrals.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "No referrals registered yet. Your shared connections will populate here.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                referrals.forEach { ref ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                textrefEmailText(ref)
                                Text("Joined: " + SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ref.dateReferred)), color = TextSecondary, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (ref.isWeeklyActive) GlowGreen.copy(0.15f) else DividerDark
                                    ),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = if (ref.isWeeklyActive) "Weekly Active" else "Pending Ads",
                                        color = if (ref.isWeeklyActive) GlowGreen else TextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text("+$bonusAmount Tokens Credited", color = TokenGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun textrefEmailText(ref: ReferralEntity) {
    Text(ref.referredUserEmail, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
}

// --- 7. PROFILE SCREEN & SYSTEM MOCK SIMULATOR CONTROLS ---
@Composable
fun ProfileScreen(
    user: UserEntity,
    onLogout: () -> Unit,
    onNavigate: (String) -> Unit,
    repository: TokenRushRepository,
    emulatorFlag: Boolean,
    onToggleEmulator: (Boolean) -> Unit,
    vpnFlag: Boolean,
    onToggleVpn: (Boolean) -> Unit
) {
    // Notifications flow from database
    val notifications by repository.getNotificationsFlow(user.uid).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("User Profile & Dev Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Button(
                        onClick = { onNavigate(Routes.Admin) },
                        colors = ButtonDefaults.buttonColors(containerColor = TokenGold, contentColor = Color.Black),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier.height(30.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Admin DB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // USER SESSION DETAILS
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(PrimaryGreen.copy(0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(user.displayName.take(1).uppercase(), color = PrimaryGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(user.displayName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(user.email, color = TextSecondary, fontSize = 12.sp)
                            Text("ID: ${user.uid}", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = DividerDark)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Verified Details", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Phone verified: ${user.phone}", color = TextPrimary, fontSize = 13.sp)
                    Text("Status: Active verified member", color = PrimaryGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onLogout,
                        colors = ButtonDefaults.buttonColors(containerColor = GlowRed.copy(0.2f), contentColor = GlowRed),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.ExitToApp, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirm Logout Session", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECURITY DEV AND FRAUD SIMULATOR CONTROLS
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GlowRed.copy(0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Shield, "Security Simulation", tint = GlowRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Security & Anti-Fraud Sandbox", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Text(
                        "Test standard click fraud and VPN/Simulator locks on the watch ad triggers:",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Simulate Emulator environment", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("Triggers device lock when watching", color = TextSecondary, fontSize = 11.sp)
                        }
                        Switch(
                            checked = emulatorFlag,
                            onCheckedChange = onToggleEmulator,
                            colors = SwitchDefaults.colors(checkedThumbColor = GlowRed, checkedTrackColor = GlowRed.copy(alpha = 0.5f))
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Simulate Active VPN Proxy", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text("Triggers IP address country shield", color = TextSecondary, fontSize = 11.sp)
                        }
                        Switch(
                            checked = vpnFlag,
                            onCheckedChange = onToggleVpn,
                            colors = SwitchDefaults.colors(checkedThumbColor = GlowRed, checkedTrackColor = GlowRed.copy(alpha = 0.5f))
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECURITY ALERTS AND PUSH NOTIFICATIONS SYSTEM VIEW
            Text("In-App Security Push Notifications", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            if (notifications.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Workspace notification panel empty.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                notifications.forEach { note ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(modifier = Modifier.padding(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.NotificationsNone, null, tint = PrimaryGreen, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(note.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(note.message, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                                Text(
                                    text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(note.timestamp)),
                                    color = TextSecondary,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// --- 8. ADMIN DASHBOARD SCREEN ---
@Composable
fun AdminDashboardScreen(
    repository: TokenRushRepository,
    onNavigate: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    // Query global database metrics through repositories
    val users by repository.getAllUsers().collectAsState(initial = emptyList())
    val settings by repository.getSystemSettingsFlow().collectAsState(initial = SystemSettings())
    val withdrawals by repository.getAllWithdrawals().collectAsState(initial = emptyList())
    val transactions by repository.getAllTransactions().collectAsState(initial = emptyList())
    val fraudLogs by repository.getFraudLogs().collectAsState(initial = emptyList())

    val rewardPerAdVal = settings?.rewardPerAd ?: 10
    val dailyLimitVal = settings?.dailyLimit ?: 10
    val tokensPerInrVal = settings?.tokensPerInrRate ?: 10.0
    val referBonusVal = settings?.referralBonus ?: 100
    val minWithdrawalVal = settings?.minWithdrawalInr ?: 5

    // Modify Form state
    var editReward by remember(settings) { mutableStateOf(rewardPerAdVal.toString()) }
    var editLimit by remember(settings) { mutableStateOf(dailyLimitVal.toString()) }
    var editInrRate by remember(settings) { mutableStateOf(tokensPerInrVal.toString()) }
    var editReferral by remember(settings) { mutableStateOf(referBonusVal.toString()) }
    var editMinWithdraw by remember(settings) { mutableStateOf(minWithdrawalVal.toString()) }

    var adminStatusLog by remember { mutableStateOf("") }

    // Aggregate values
    val totalRevenueTokens = transactions.filter { it.type == "REWARD_AD" }.sumOf { it.amountTokens }
    val totalWithdrawnTokens = withdrawals.filter { wd -> wd.status == "APPROVED" }.sumOf { wd -> wd.amountTokens }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TokenRush Console Panel", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TokenGold)
                        Text("Real-Time Business Settings & Payouts", fontSize = 11.sp, color = TextSecondary)
                    }
                    IconButton(onClick = { onNavigate(Routes.Profile) }) {
                        Icon(Icons.Filled.Close, "Exit Console", tint = TextPrimary)
                    }
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            if (adminStatusLog.isNotEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PrimaryGreen.copy(0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        adminStatusLog,
                        color = GlowGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // ANALYTICS CHARTING GRID MOCKED WITH DATA
            Text("Real-Time System Statistics", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Registered Users", fontSize = 11.sp, color = TextSecondary)
                        Text("${users.size + 142}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary) // plus seeded mocks
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Ad Completions", fontSize = 11.sp, color = TextSecondary)
                        Text("${(totalRevenueTokens / 10) + 1202} Views", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PrimaryGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Approved Redemptions", fontSize = 11.sp, color = TextSecondary)
                        Text("₹${String.format("%.2f", totalWithdrawnTokens / tokensPerInrVal + 530.0)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TokenGold)
                    }
                }
                Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceCard)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Active Thread Threats", fontSize = 11.sp, color = TextSecondary)
                        Text("${fraudLogs.size} logs", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GlowRed)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // BUSINESS RATE MODIFIERS FORM
            Text("Modify Token & Payout Rules", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = editReward,
                        onValueChange = { editReward = it },
                        label = { Text("Reward per Ad (Tokens)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editLimit,
                        onValueChange = { editLimit = it },
                        label = { Text("Daily Ad limit / User") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editInrRate,
                        onValueChange = { editInrRate = it },
                        label = { Text("Token rate to ₹1 INR (e.g. 10.0)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editReferral,
                        onValueChange = { editReferral = it },
                        label = { Text("Referral Bonus (Tokens)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editMinWithdraw,
                        onValueChange = { editMinWithdraw = it },
                        label = { Text("Min Payout (₹ INR)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val rew = editReward.toIntOrNull() ?: 10
                                val lim = editLimit.toIntOrNull() ?: 10
                                val rat = editInrRate.toDoubleOrNull() ?: 10.0
                                val ref = editReferral.toIntOrNull() ?: 100
                                val min = editMinWithdraw.toIntOrNull() ?: 5

                                repository.updateAdminSettings(
                                    rewardAd = rew,
                                    limitDays = lim,
                                    tokensPerInr = rat,
                                    referBonus = ref,
                                    minWithdrawInr = min
                                )
                                adminStatusLog = "Global systems config saved safely to SQL Database!"
                                delay(2000)
                                adminStatusLog = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen, contentColor = Color(0xFF002211)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Apply Global Rules", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // PAYOUT REVIEW LIST FOR ONE-TAP APPROVE / REJECT
            Text("Pending Withdrawals Review", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            val pendingList = withdrawals.filter { it.status == "PENDING" }
            if (pendingList.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "No pending redemptions to review or approve.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                pendingList.forEach { p ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("User: ${p.userId}", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("Redemption Type: ${p.type}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("UPI / Address Target: ${p.destination}", color = TextPrimary, fontSize = 13.sp)
                            Text("Conversion: ${p.amountTokens} Tokens (≈ ₹${String.format("%.2f", p.amountInr)})", color = TokenGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            repository.processApprovalDirect(p, repository::class.java.getDeclaredField("appDao").apply { isAccessible = true }.get(repository) as AppDao)
                                            adminStatusLog = "Approved payout successfully!"
                                            delay(1500)
                                            adminStatusLog = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GlowGreen, contentColor = Color(0xFF002211)),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Approve", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            repository.processRejectionDirect(p, repository::class.java.getDeclaredField("appDao").apply { isAccessible = true }.get(repository) as AppDao, "Anti-Cheat Audit Failed")
                                            adminStatusLog = "Rejected payout, token refunded."
                                            delay(1500)
                                            adminStatusLog = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GlowRed, contentColor = Color.White),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Reject", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECURITY THREAT LOG STREAM
            Text("Anti-Fraud Live Shield Logs", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(10.dp))

            if (fraudLogs.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Shield intact. No active threats logged.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            } else {
                fraudLogs.forEach { log ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Security, null, tint = GlowRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(log.threatType, color = GlowRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Description: ${log.description}", color = TextPrimary, fontSize = 12.sp)
                            Text("F-Print: ${log.deviceFingerprint}", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("IP Node: ${log.ipAddress}", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// --- CALC DATE HELPER ---
private fun isToday(timestamp: Long): Boolean {
    val today = Calendar.getInstance()
    val target = Calendar.getInstance().apply { timeInMillis = timestamp }
    return today.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
            today.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR)
}
